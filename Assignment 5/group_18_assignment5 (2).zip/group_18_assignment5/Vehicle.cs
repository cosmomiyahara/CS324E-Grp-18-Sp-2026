using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
namespace group_18_assignment5;

public class Vehicle
{
    private float angle;
    private float radius;
    private float speed; 
    private Model carModel;
    private float scaleSize = 1.5f;
    private float modelRotationOffset = MathHelper.PiOver2;
    public Matrix World { get; private set; }

    public Vehicle(Model model, float trackRadius, float startAngle, float travelSpeed)
    {
        carModel = model;
        radius = trackRadius;
        angle = startAngle;
        speed = travelSpeed;
    }
    
    public void Update(GameTime gameTime)
    {
        float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
    
        angle -= speed * dt;
        angle = MathHelper.WrapAngle(angle);

      
        // Scale the model down if it's too big
        Matrix scale = Matrix.CreateScale(scaleSize);
        
        Matrix localRotation = Matrix.CreateRotationY(modelRotationOffset);

        Matrix offsetTranslation = Matrix.CreateTranslation(new Vector3(radius, 0.1f, 0));

        Matrix orbitRotation = Matrix.CreateRotationY(angle);

     
        World = scale * localRotation * offsetTranslation * orbitRotation;
    }
    
    public void Draw(Matrix view, Matrix projection)
    {
        foreach (ModelMesh mesh in carModel.Meshes)
        {
            foreach (BasicEffect effect in mesh.Effects)
            {
                effect.World = World;
                effect.View = view;
                effect.Projection = projection;
                
                effect.EnableDefaultLighting(); 
                effect.TextureEnabled = true; 
            }
            mesh.Draw();
        }
    }


}