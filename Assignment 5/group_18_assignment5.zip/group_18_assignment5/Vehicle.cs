using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
namespace group_18_assignment5;

public class Vehicle
{
    private float angle;
    private float radius;
    private float speed; // Angular speed (how fast it rotates)
    private Model carModel;
    private float scaleSize = 1.5f;
    private float modelRotationOffset = MathHelper.PiOver2;
    public Matrix World { get; private set; }

    public Vehicle(Model model, float trackRadius, float startAngle, float travelSpeed)
    {
        carModel = model;
        radius = trackRadius;
        angle = startAngle;
        speed = travelSpeed;
    }
    
    public void Update(GameTime gameTime)
    {
        float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
    
        // 1. Update the angle for clockwise movement
        angle -= speed * dt;
        angle = MathHelper.WrapAngle(angle);

        // 2. Build the transformation matrices
        // Scale the model down if it's too big
        Matrix scale = Matrix.CreateScale(scaleSize);
        
        // Spin the model on its own center if it was exported facing sideways
        Matrix localRotation = Matrix.CreateRotationY(modelRotationOffset);

        // Move OUT along the X-axis by the radius amount (Y is 0.1f to hover over the track)
        Matrix offsetTranslation = Matrix.CreateTranslation(new Vector3(radius, 0.1f, 0));

        // Rotate around the center of the world (orbiting)
        Matrix orbitRotation = Matrix.CreateRotationY(angle);

        // 3. Combine them into the final World matrix. Order matters!
        // Scale -> Local Spin -> Push Out to Radius -> Orbit Around Center
        World = scale * localRotation * offsetTranslation * orbitRotation;
    }
    
    public void Draw(Matrix view, Matrix projection)
    {
        foreach (ModelMesh mesh in carModel.Meshes)
        {
            foreach (BasicEffect effect in mesh.Effects)
            {
                effect.World = World;
                effect.View = view;
                effect.Projection = projection;
                
                // Make sure we can see the colors and lighting!
                effect.EnableDefaultLighting(); 
                effect.TextureEnabled = true; 
            }
            mesh.Draw();
        }
    }


}