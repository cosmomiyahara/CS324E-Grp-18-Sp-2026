﻿//A5 group 18, Cosmo, Zaviyan, Brady

using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace group_18_assignment5;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    VertexPositionColor[] trackSmall;
    VertexPositionColor[] trackLarge;
    BasicEffect effect;
    Model carModel;
    Vehicle playerVehicle;
    


    // Transformation Matrices
    Matrix world = Matrix.Identity;
    Matrix view = Matrix.CreateLookAt(new Vector3(0, 100, 50), Vector3.Zero, Vector3.Up);
    Matrix projection;
    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here
        projection = Matrix.CreatePerspectiveFieldOfView(
            MathHelper.ToRadians(45),
            GraphicsDevice.Viewport.AspectRatio, 
            0.1f, 1000f);

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);
        effect = new BasicEffect(GraphicsDevice);
        int segments = 100;

        // Generate the small circuit (inner)
        trackSmall = CreateTrack(segments, 12f, 4f, Color.DarkSlateGray);
        
        // Generate the large circuit (outer)
        trackLarge = CreateTrack(segments, 20f, 4f, Color.Gray);
        carModel = Content.Load<Model>("FREE_CAR_01");
        playerVehicle = new Vehicle(carModel, 15f, 0f, 1.5f);
    }
    // Helper method to keep your LoadContent clean
    private VertexPositionColor[] CreateTrack(int segments, float radius, float thickness, Color color)
    {
        VertexPositionColor[] vertices = new VertexPositionColor[(segments + 1) * 2];

        for (int i = 0; i <= segments; i++)
        {
            float angle = MathHelper.TwoPi * i / segments;
            float x = (float)Math.Cos(angle);
            float z = (float)Math.Sin(angle);

            // Inner edge of the ribbon
            vertices[i * 2] = new VertexPositionColor(
                new Vector3(x * (radius - thickness / 2), 0, z * (radius - thickness / 2)), color);

            // Outer edge of the ribbon
            vertices[i * 2 + 1] = new VertexPositionColor(
                new Vector3(x * (radius + thickness / 2), 0, z * (radius + thickness / 2)), color);
        }
        return vertices;
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
            Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        // TODO: Add your update logic here
        playerVehicle.Update(gameTime);

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);

        // Required for 3D depth - ensures tracks don't "flicker" through each other
        GraphicsDevice.DepthStencilState = DepthStencilState.Default;

        effect.World = world;
        effect.View = view;
        effect.Projection = projection;
        effect.VertexColorEnabled = true;

        foreach (EffectPass pass in effect.CurrentTechnique.Passes)
        {
            pass.Apply();

            // Draw Small Circuit
            GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleStrip, 
                trackSmall, 0, trackSmall.Length - 2);
        
            // Draw Large Circuit
            GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleStrip, 
                trackLarge, 0, trackLarge.Length - 2);
        }
        playerVehicle.Draw(view, projection);

        base.Draw(gameTime);
    }
}