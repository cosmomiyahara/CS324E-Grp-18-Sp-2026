﻿// Group 18: Cosmo Miyahara, Zaviyan Tharwani,Brady Backus
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace group_18_assignment6;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    
    // Bird management
    private List<Birds> _birds;
    private Texture2D _birdTexture;

    // Interaction
    private Vector2 _seedPosition;
    
    //Vines
    private MouseState _lastMouseState;
    private KeyboardState _lastKeyboardState;
    private Texture2D _vineTexture;
    private Texture2D _background;
    private Texture2D _background1;
    private List<Vine> _vines;
    private Vector2 _gravity;
    private Color _backGroundColor;
    private bool _addingVines = false;

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
        _gravity = new Vector2(0f, 0.5f);
        _vines = new List<Vine>();
    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here
        // Set up a standard window size for the jungle scene
        _graphics.PreferredBackBufferWidth = 1280;
        _graphics.PreferredBackBufferHeight = 720;
        _graphics.ApplyChanges();

        // Start the seed in the center of the screen
        _seedPosition = new Vector2(
            _graphics.PreferredBackBufferWidth / 2f, 
            _graphics.PreferredBackBufferHeight / 2f
        );
        _birds = new List<Birds>();

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);
        _birdTexture = Content.Load<Texture2D>("Minimalist seagull in flight");
        System.Random rand = new System.Random();

        for (int i = 0; i < 30; i++)
        {
            // 1. Calculate a safe padding based on the texture height and your 0.2f scale.
            // We cast it to an (int) because the random number generator requires whole numbers.
            int safePadding = (int)(_birdTexture.Height * 0.05f);

            // 2. Calculate the middle of the screen
            int screenMiddle = -120 + (_graphics.PreferredBackBufferHeight / 2);

            // 3. Spawn the birds between the top padding and the middle of the screen
            Vector2 randomStart = new Vector2(
                rand.Next(0, _graphics.PreferredBackBufferWidth),
                // Min Y is the top padding, Max Y is the middle of the screen minus padding
                rand.Next(safePadding, screenMiddle - safePadding) 
            );
            _birds.Add(new Birds(_birdTexture, randomStart, _graphics.PreferredBackBufferWidth));
        }
        //Vines
        _vineTexture =  Content.Load<Texture2D>("Vine");
        _background = Content.Load<Texture2D>("Background");
        _background1 = Content.Load<Texture2D>("Background1");
        _backGroundColor = Color.White;
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
            Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        // TODO: Add your update logic here
        // Allow the user to move the seed with the mouse
        MouseState mouseState = Mouse.GetState();
        if (mouseState.LeftButton == ButtonState.Pressed)
        {
            _seedPosition = new Vector2(mouseState.X, mouseState.Y);
        }
        for (int i = 0; i < _birds.Count; i++)
        {
            _birds[i].Update(gameTime);
        }
        
        //Vines
        KeyboardState keyboardState = Keyboard.GetState();
        if (keyboardState.IsKeyDown(Keys.V) && _lastKeyboardState.IsKeyUp(Keys.V))
        {
            _addingVines = ! _addingVines;
            if (_addingVines)
            {
                _backGroundColor = Color.Gray;
            }
            else
            {
                _backGroundColor = Color.White;
            }
        }
        if ((mouseState.LeftButton == ButtonState.Pressed) && (_lastMouseState.LeftButton == ButtonState.Released) && (mouseState.Y < 235) && (_addingVines))
        {
            _vines.Add(new Vine(_vineTexture, new  Vector2(mouseState.X, mouseState.Y), _gravity, 1.0f));
            Console.WriteLine("active");
        }
        else if ((mouseState.LeftButton == ButtonState.Pressed) && (_lastMouseState.LeftButton == ButtonState.Released))
        {
            for (int i = 0; _vines.Count > i; i++)
            {
                _vines[i].LinkCheck();
            }
        }
        if ((mouseState.LeftButton == ButtonState.Released) && (_lastMouseState.LeftButton == ButtonState.Pressed))
        {
            for (int i = 0; _vines.Count > i; i++)
            {
                _vines[i].LinkCheck();
            }
        }
        for (int i = 0; i < _vines.Count; i++)
        {
            _vines[i].Update(gameTime);
        }
        for (int i = 0; i < _birds.Count; i++)
        {
            // 1. Check for vines to avoid
            _birds[i].AvoidVines(_vines);
    
            // 2. Then update their position
            _birds[i].Update(gameTime);
        }

        _lastKeyboardState = keyboardState;
        _lastMouseState = mouseState;
        
        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        // TODO: Add your drawing code here
        // A nice deep jungle green background
        GraphicsDevice.Clear(new Color(20, 60, 30));
        Rectangle screenRect = new Rectangle(0, 0, _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);

        _spriteBatch.Begin();

        // Draw the target "seed" as a small red dot (using the same texture but tinted)
        //_spriteBatch.Draw(_birdTexture, _seedPosition, null, Color.Red, 0f, new Vector2(5, 5), 1f, SpriteEffects.None, 0f);
        _spriteBatch.Draw(_background, screenRect, _backGroundColor);
        for (int i = 0; i < _birds.Count; i++)
        {
            _birds[i].Draw(_spriteBatch);
        }
        for (int i = 0; i < _vines.Count; i++)
        {
            _vines[i].Draw(_spriteBatch);
        }
        if (!_addingVines)
        {
            
            _spriteBatch.Draw(_background1, Vector2.Zero, _backGroundColor);
        }

        _spriteBatch.End();

        base.Draw(gameTime);
    }
}