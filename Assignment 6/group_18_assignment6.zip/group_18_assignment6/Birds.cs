// Cosmo Miyahara

using System.Collections.Generic;

namespace group_18_assignment6;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
public class Birds
{
    // Physics properties
    public Vector2 Position { get; private set; }
    public Vector2 Velocity { get; private set; }
    
    // Customization properties
    public float Scale { get; set; }
    private float _speed;

    // Visuals
    private Texture2D _texture;
    private SpriteEffects _spriteFacing;

    // Screen bounds (needed for the looping behavior)
    private int _screenWidth;
    
    private float _startY;
    private float _bobSpeed;
    private float _bobHeight;
    private float _timeOffset;

    public Birds(Texture2D texture, Vector2 startPosition, int screenWidth)
    {
        _texture = texture;
        Position = startPosition;
        _screenWidth = screenWidth;
        
        // FIX 1: Make them small. Set a fixed, small scale here.
        // 0.2f means 20% of original size. Adjust as needed!
        Scale = 0.1f; 

        // FIX 3: Set up simple horizontal movement.
        _speed = 3.0f; // How fast they fly

        // Randomly decide if this specific bird starts flying left or right
        Random rand = new Random();
        if (rand.Next(0, 2) == 0)
        {
            // Fly Right
            Velocity = new Vector2(_speed, 0);
            _spriteFacing = SpriteEffects.None; // Assuming sprite naturally faces right
        }
        else
        {
            // Fly Left
            Velocity = new Vector2(-_speed, 0);
            _spriteFacing = SpriteEffects.FlipHorizontally;
        }
        // Set up the Sine-Wave rules
        _startY = startPosition.Y;
        
        // Randomize how fast they bob (e.g., between 2.0 and 4.0)
        _bobSpeed = 2.0f + (float)rand.NextDouble() * 2.0f; 
        
        // Randomize how high they bob (e.g., between 10 and 25 pixels)
        _bobHeight = 20.0f + (float)rand.Next(0, 15); 
        
        // Give each bird a random starting point on the sine wave so they are out of sync
        _timeOffset = (float)rand.NextDouble() * 10f;
    }

    // NOTE: You can delete the old ApplyForce, ApplyGravity, and Seek methods!
    // They are no longer needed for this simple movement.

    public void Update(GameTime gameTime)
    {
        // 1. Apply the horizontal velocity rule
        Position += Velocity; 

        // 2. Apply the Sine-Wave vertical oscillation rule
        float time = (float)gameTime.TotalGameTime.TotalSeconds;
        float newY = _startY + (float)Math.Sin(time * _bobSpeed + _timeOffset) * _bobHeight;
        
        // Update the position with the newly calculated Y
        Position = new Vector2(Position.X, newY);
    
        // Calculate the actual width of the sprite on screen after scaling
        float visualWidth = _texture.Width * Scale;

        // Check Right Edge: 
        // Trigger when the bird's Position + its width hits the screen edge
        if (Position.X > (_screenWidth - visualWidth))
        {
            // Snap the bird back slightly so it doesn't get stuck in the wall
            Position = new Vector2(_screenWidth - visualWidth, Position.Y); 
        
            // Turn around and fly left
            Velocity = new Vector2(-_speed, 0);
            _spriteFacing = SpriteEffects.FlipHorizontally;
        }
    
        // Check Left Edge: 
        // Trigger the moment the left edge of the bird hits 0
        else if (Position.X < 0)
        {
            // Snap the bird back slightly so it doesn't get stuck
            Position = new Vector2(0, Position.Y); 
        
            // Turn around and fly right
            Velocity = new Vector2(_speed, 0);
            _spriteFacing = SpriteEffects.None;
        }
    }
    public void AvoidVines(List<Vine> vines)
    {
        // How close (in pixels) the bird gets before turning around. 
        // Tweak this number to make them more or less brave!
        float avoidanceRadius = 30f; 

        foreach (var vine in vines)
        {
            // Loop through every link in this specific vine
            foreach (var link in vine.Links)
            {
                float distance = Vector2.Distance(Position, link.Position);
            
                // If the bird is inside the panic radius...
                if (distance < avoidanceRadius)
                {
                    // Are we flying RIGHT, and the vine is to our RIGHT?
                    if (Velocity.X > 0 && link.Position.X > Position.X)
                    {
                        // Turn around and fly left
                        Velocity = new Vector2(-Math.Abs(Velocity.X), 0);
                        _spriteFacing = SpriteEffects.FlipHorizontally;
                        return; // Stop checking, we already turned around
                    }
                    // Or are we flying LEFT, and the vine is to our LEFT?
                    else if (Velocity.X < 0 && link.Position.X < Position.X)
                    {
                        // Turn around and fly right
                        Velocity = new Vector2(Math.Abs(Velocity.X), 0);
                        _spriteFacing = SpriteEffects.None;
                        return; // Stop checking
                    }
                }
            }
        }
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        // FIX 2: Remove varied orientations.
        // Rotation is hardcoded to 0f so they always stay level.

        // Draw the bird centered vertically, but we no longer care about horizontal centering
        // since rotation isn't a factor.
        Vector2 origin = new Vector2(0, _texture.Height / 2f);

        // Apply the scale and the FlipHorizontally effect based on direction
        spriteBatch.Draw(_texture, Position, null, Color.White, 0f, origin, Scale, _spriteFacing, 0f);
    }
}