﻿using var game = new group_18_assignment6.Game1();
game.Run();