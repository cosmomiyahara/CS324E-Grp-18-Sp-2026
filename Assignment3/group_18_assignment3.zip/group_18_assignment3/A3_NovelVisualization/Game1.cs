﻿//Cosmo Miyahara, Samantha Lopez, Zaviyan Tharwani
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;

namespace A3_NovelVisualization;

//State Management

public enum DisplayMode {UniqueWords, WordFrequency}

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    private Color[] _palette;
    private Random _random;
    private List<string> _allUniqueWords;
    private Dictionary<int, int> _frequencyData;
    private SpriteFont _font;
    private MouseState _previousMouseState;
    private DisplayMode _currentMode = DisplayMode.UniqueWords;
    private KeyboardState _prevKeyState;
    private List<(string text, Vector2 position, Color color)> _wordsToDraw;
    private List<(Vector2 pos, Color color, float scale)> _nebulaPoints;
    private Texture2D _pixel; //Draw nebula dots
    

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
        //Set the display 700 x 600
        _graphics.PreferredBackBufferWidth = 700;
        _graphics.PreferredBackBufferHeight = 600;
    }


    protected override void Initialize()
    {
        _random = new Random();
        //initializing arrays of information
        //for color
        _palette =
        [
            new Color(204, 51, 25),
            new Color(76, 127, 204),
            new Color(51, 204, 51)
        ];
        //for unique words
        _allUniqueWords = [];
        //for words to draw
        _wordsToDraw = [];
        //for nebula points
        _nebulaPoints = [];
        //to store the frequency data in a dictionary
        _frequencyData = new Dictionary<int, int>();

        //Opening the files 
        try
        {
           
            using (var stream = TitleContainer.OpenStream("Content/text/uniquewords.txt"))
            using (var reader = new StreamReader(stream))
            {
                string fullText = reader.ReadToEnd();
                //split the text when encountering a space, return, newline, or tab
                _allUniqueWords = fullText.Split([' ', '\r', '\n', '\t'], StringSplitOptions.RemoveEmptyEntries)
                    //Make it a list
                    .ToList();
            }

       
            using (var stream = TitleContainer.OpenStream("Content/text/wordfrequency.txt"))
            using (var reader = new StreamReader(stream))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    //precautions to ignore source header and ensure the line contains data
                    if (line.Contains(":") && !line.Contains("["))
                    {
                        var parts = line.Split(':');
                        //Converts the strings to integers freq and count
                        if (int.TryParse(parts[0].Trim(), out int freq) && int.TryParse(parts[1].Trim(), out int count))
                        {
                            _frequencyData[freq] = count; 
                        }
                    }
                }
            }
        }
        //so the program doesn't crash
        catch (Exception ex)
        {
            
            Console.WriteLine("Error loading files: " + ex.Message);
            _allUniqueWords = ["Error", "Loading", "Files"];
        }

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);
        _font = Content.Load<SpriteFont>("text/font");
        _pixel = new Texture2D(GraphicsDevice, 1, 1);
        //initialize pixel color as neutral
        _pixel.SetData(new[] { Color.White });
        DisplayUniqueWords();


        // TODO: use this.Content to load your game content here
    }

    private void DisplayUniqueWords()
    {
        _wordsToDraw.Clear();
        Random rand = new Random();
        //The cursors
        float currentX = 20;
        float currentY = 20;
        float spacing = 15f;
        float lineHeight = _font.MeasureString("Ay").Y + 5;
        //shuffle the words
        var shuffledWords = _allUniqueWords.OrderBy(x => rand.Next()).ToList();
        foreach (var word in shuffledWords)
        {
            //prevents crashing if there is a character not compatible with the font
            string safeWord = new string(word.Where(c => _font.Characters.Contains(c)).ToArray());
            if (string.IsNullOrWhiteSpace(safeWord)) continue;
            Vector2 size = _font.MeasureString(safeWord);

            if (currentX + size.X > _graphics.PreferredBackBufferWidth - 20)
            {
                currentX = 20;
                currentY += lineHeight;
            }

            if (currentY + size.Y > _graphics.PreferredBackBufferHeight - 20)
                break;
            
            Color wordColor = _palette[rand.Next(_palette.Length)];
            //store the words that will be displayed
            _wordsToDraw.Add((safeWord, new Vector2(currentX, currentY), wordColor));

            currentX += size.X + spacing;

        }
    }

    private void DisplayWordFrequency()
    {
        _nebulaPoints.Clear();
        Vector2 center = new Vector2(350, 300);
        int maxFreq = _frequencyData.Keys.Max(); 

        foreach (var entry in _frequencyData)
        {
            int freq = entry.Key;
            int count = entry.Value;
            
            //logarithmic equation
            float norm = (float)Math.Log(freq) / (float)Math.Log(maxFreq);
            //how far from the center a point should be
            float baseDist = 280 * (1 - norm);

            for (int i = 0; i < count; i++)
            {
                float angle = (float)_random.NextDouble() * MathHelper.TwoPi;
                float dist = baseDist + _random.Next(-15, 15);
                Vector2 pos = center + new Vector2((float)Math.Cos(angle) * dist, (float)Math.Sin(angle) * dist);

                // Assign colors based on frequency "tier"
                //a bunch of if else statements using ? and :
                Color c = (freq == 1) ? _palette[0] : (freq < 50) ? _palette[1] : _palette[2];
                float scale = (freq > 100) ? 4f : 2f;

                _nebulaPoints.Add((pos, c, scale));
            }
        }
    }
    

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
            Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        // TODO: Add your update logic here
        KeyboardState kState = Keyboard.GetState();
        if (kState.IsKeyDown(Keys.Enter) && _prevKeyState.IsKeyUp(Keys.Enter))
        {
            _currentMode = (_currentMode == DisplayMode.UniqueWords) ? DisplayMode.WordFrequency : DisplayMode.UniqueWords;
            
            if (_currentMode == DisplayMode.UniqueWords) DisplayUniqueWords();
            else DisplayWordFrequency();
        }
        MouseState currentMouseState = Mouse.GetState();
        if (currentMouseState.LeftButton == ButtonState.Pressed &&
            _previousMouseState.LeftButton == ButtonState.Released)
        {
            DisplayUniqueWords();
        }
        _prevKeyState = kState;
        _previousMouseState = currentMouseState;
        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.FloralWhite);

        // TODO: Add your drawing code here
        _spriteBatch.Begin();
        if (_currentMode == DisplayMode.UniqueWords)
        {
            foreach (var w in _wordsToDraw)
                _spriteBatch.DrawString(_font, w.text, w.position, w.color);
        }
        else
        {
            foreach (var p in _nebulaPoints)
                
                _spriteBatch.Draw(_pixel, p.pos, null,
                    p.color, 0f, Vector2.Zero,
                    p.scale, SpriteEffects.None, 0f);
        }
        _spriteBatch.End();
        

        base.Draw(gameTime);
    }
}