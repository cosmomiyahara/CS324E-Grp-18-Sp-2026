﻿using var game = new A3_NovelVisualization.Game1();
game.Run();