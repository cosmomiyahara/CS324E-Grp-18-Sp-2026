﻿using var game = new TeamPMA_finalproject.Game1();
game.Run();